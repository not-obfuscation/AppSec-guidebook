ORIGIN = 'attacker'
